$(document).ready(function(){
	load_data("PL")
});




function load_data(championship){

	$(".active").removeClass("active")
	$("#" + championship).addClass("active");
	$("#predictions").addClass("active");


	$.post('/load_predictions_data', {"championship" : championship}, function(raw_data){
		data = JSON.parse(raw_data)
		//console.log(data[data.length - 1]);

		var last_date = '';
		var table_body = '';
		

		for(i =0;i<data.length;i++){

			if (last_date != data[i]['Date']){
				if (table_body != ''){
					table_body += '</tbody></table>';
				};
				
				table_body += '<h1 class="mt-5"> Matchs du ' + data[i]['Date'] + '</h1>';
				table_body += '<table class="table table-striped table-hover"><thead><tr><th style="width : 35%;">Domicile</th><th style="width : 10%;"></th><th style="width : 10%;">Egalite</th><th style="width : 10%;"></th><th style="width : 35%;">Exterieur</th></tr></thead><tbody>';
				last_date = data[i]['Date'];
			};

			table_body+='<tr>';

			table_body +='<td>';
			table_body += data[i]['HomeTeam'];
			table_body +='</td>';

			var home_color = 255 - 2.55*data[i]["home_win_prob"]
			table_body +='<td class="white" style="background-color : rgb(' + home_color + ',' + home_color + ',' + home_color + ')">';
			table_body += data[i]["home_win_prob"];
			table_body +='</td>';

			var draw_color = 255 - 2.55*data[i]["draw_prob"]
			table_body +='<td class="white" style="background-color : rgb(' + draw_color + ',' + draw_color + ',' + draw_color + ')">';
			table_body += data[i]["draw_prob"];
			table_body +='</td>';

			var away_color = 255 - 2.55*data[i]["away_win_prob"]
			table_body +='<td class="white" style="background-color : rgb(' + away_color + ',' + away_color + ',' + away_color + ')">';
			table_body += data[i]["away_win_prob"];
			table_body +='</td>';
							 
			table_body +='<td>';
			table_body += data[i]["AwayTeam"];
			table_body +='</td>';
						
			table_body+='</tr>';
		}

		table_body+='</tbody></table>';

		$('#prediction_table').html(table_body);
	});
};