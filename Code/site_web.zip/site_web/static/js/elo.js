$(document).ready(function(){
	load_data('PL')
});

function load_data(championship){

	$(".active").removeClass("active")
	$("#" + championship).addClass("active");
	$("#elo").addClass("active");

	$.post('/load_elo_data', {"championship" : championship}, function(raw_data){

		data = JSON.parse(raw_data)
		var graph_data = [];
		var table_body = '<table class="table table-striped table-hover"><thead><tr><th scope="col">Position</th><th scope="col">Equipe</th><th scope="col">Elo</th></tr></thead><tbody>';

		console.log(data)

		for(i =0;i<data.length;i++){

			var trace = {
				x: data[i]["date list"],
				y: data[i]["elo list"],
				name: data[i]["team"],
				mode: "lines",
				type: 'scatter'
			};

			graph_data.push(trace);

			var layout = {
			  xaxis: {
			  	range: ['2018-07-01', '2019-6-01'],
			    type: 'date',
			    title: 'Date'
			  },
			  yaxis: {
			    title: 'Points Elo'
			  },
			  hovermode : 'closest',
			  title:'Evolution des points Elo en fonction du temps'
			};

			table_body+='<tr>';

			table_body +='<td>';
			table_body += i+1;
			table_body +='</td>';

			table_body +='<td>';
			table_body += data[i]["team"];
			table_body +='</td>';
							 
			table_body +='<td>';
			table_body += Math.round(data[i]["final elo"]);
			table_body +='</td>';
						
			table_body+='</tr>';
		}

		table_body+='</tbody></table>';

		$('#elo_table').html(table_body);

		Plotly.newPlot('elo_graph', graph_data, layout);
	});
};

/*function load_graph(){
	$.get('/load_elo_graph', function(raw_data){
		var trace1 = {
			x: [1, 2, 3, 4],
			y: [10, 15, 13, 17],
			mode: 'markers',
			type: 'scatter'
		};

		var trace2 = {
			x: [2, 3, 4, 5],
			y: [16, 5, 11, 9],
			mode: 'lines',
			type: 'scatter'
		};

		var trace3 = {
			x: [1, 2, 3, 4],
			y: [12, 9, 15, 12],
			mode: 'lines+markers',
			type: 'scatter'
		};

		var data = [trace1, trace2, trace3];

		Plotly.newPlot('elo_graph', data);
	})
}*/