import json

from flask import *
from elo import *



app = Flask(__name__)

FLASK_DEBUG=1

def format_elo_date(tuple_list):
    elo_list, date_list = [], []
    for element in tuple_list:
        elo_list.append(round(element[0]))
        
        raw_date = element[1]
        #raw date is like dd/mm/yyyy
        day = raw_date[:2]
        month = raw_date[3:5]
        year = "20" + raw_date[6:]
        
        if int(year) > 3000:
            year = year[2:]
        
        date_list.append(year + '-' + month + '-' + day)
    
    return elo_list, date_list
        
        
    

@app.route('/')
def accueil():
    return render_template('index.html')

@app.route('/elo')
def elo():
    return render_template('elo.html')

@app.route('/load_elo_data', methods=['GET', 'POST'])
def load_elo_data():
    
    if request.form.get('championship') == 'PL':
        dir_name = 'static/csv_uk/'
        match_nb = 380
    elif request.form.get('championship') == 'L1':
        dir_name = 'static/csv_fr/'
        match_nb = 380
    elif request.form.get('championship') == 'liga':
        dir_name = 'static/csv_es/'
        match_nb = 380
    else :
        dir_name = 'static/csv_al/'
        match_nb = 306
        
    tab2006 = pd.read_csv(dir_name + '2006_2007.csv')
    tab2007 = pd.read_csv(dir_name + '2007_2008.csv')
    tab2008 = pd.read_csv(dir_name + '2008_2009.csv')
    tab2009 = pd.read_csv(dir_name + '2009_2010.csv')
    tab2010 = pd.read_csv(dir_name + '2010_2011.csv')
    tab2011 = pd.read_csv(dir_name + '2011_2012.csv')
    tab2012 = pd.read_csv(dir_name + '2012_2013.csv')
    tab2013 = pd.read_csv(dir_name + '2013_2014.csv')
    tab2014 = pd.read_csv(dir_name + '2014_2015.csv')
    tab2015 = pd.read_csv(dir_name + '2015_2016.csv')
    tab2016 = pd.read_csv(dir_name + '2016_2017.csv')
    tab2017 = pd.read_csv(dir_name + '2017_2018.csv')
    tab2018 = pd.read_csv(dir_name + '2018_2019.csv')
    
    df = pd.concat((tab2006, tab2007, tab2008, tab2009, tab2010, tab2011, tab2012, tab2013, tab2014, tab2015, tab2016, tab2017, tab2018), sort=False, ignore_index = True)
    
    elo, percentage, E_predictions, prediction_list = set_elo(df, match_nb)
    
    team_list = list(tab2018['HomeTeam'].drop_duplicates())

    def elo_sort(team):
        return elo[team][-1]
    
    team_list.sort(key=elo_sort, reverse=True)
    
    table_data = []
    
    for team in team_list:
        obj = {}
        obj["team"] = team
        obj["final elo"] = elo[team][-1][0]
        obj["elo list"], obj["date list"] = format_elo_date(elo[team])
        #[elo[team][i][0] for i in range(len(elo[team]))]
        #obj["date list"] = format_date(elo[team])
           #[elo[team][i][1] for i in range(len(elo[team]))]

        table_data.append(obj)

    
    return json.dumps(table_data)

@app.route('/load_predictions_data', methods=['GET', 'POST'])
def load_predictions_data():
    
    #dir_name = ''
    
    if request.form.get('championship') == 'PL':
        dir_name = 'static/csv_uk/'
        match_nb = 380
    elif request.form.get('championship') == 'L1':
        dir_name = 'static/csv_fr/'
        match_nb = 380
    elif request.form.get('championship') == 'liga':
        dir_name = 'static/csv_es/'
        match_nb = 380
    else :
        dir_name = 'static/csv_al/'
        match_nb = 306
    
    
    tab2006 = pd.read_csv(dir_name + '2006_2007.csv')
    tab2007 = pd.read_csv(dir_name + '2007_2008.csv')
    tab2008 = pd.read_csv(dir_name + '2008_2009.csv')
    tab2009 = pd.read_csv(dir_name + '2009_2010.csv')
    tab2010 = pd.read_csv(dir_name + '2010_2011.csv')
    tab2011 = pd.read_csv(dir_name + '2011_2012.csv')
    tab2012 = pd.read_csv(dir_name + '2012_2013.csv')
    tab2013 = pd.read_csv(dir_name + '2013_2014.csv')
    tab2014 = pd.read_csv(dir_name + '2014_2015.csv')
    tab2015 = pd.read_csv(dir_name + '2015_2016.csv')
    tab2016 = pd.read_csv(dir_name + '2016_2017.csv')
    tab2017 = pd.read_csv(dir_name + '2017_2018.csv')
    tab2018 = pd.read_csv(dir_name + '2018_2019.csv')
    
    df = pd.concat((tab2006, tab2007, tab2008, tab2009, tab2010, tab2011, tab2012, tab2013, tab2014, tab2015, tab2016, tab2017, tab2018), sort=False, ignore_index = True)    
    
    elo = set_elo(df, match_nb)[0]
    
    match_list = []
    
    for i in range(match_nb - 1, -1, -1):
        home_win_prob, draw_prob, away_win_prob = get_elo_probabilities(df, elo, tab2018["HomeTeam"][i], tab2018["AwayTeam"][i])
        
        match = {}
        match["HomeTeam"] = tab2018["HomeTeam"][i]
        match["AwayTeam"] = tab2018["AwayTeam"][i]
        match["Date"] = tab2018["Date"][i]
        match['home_win_prob'] = home_win_prob
        match['draw_prob'] = draw_prob
        match['away_win_prob'] = away_win_prob
        
        
        
        

        match_list.append(match)
    
    #match_list.append({"debug" : request.form.get('championship')})
        
    return json.dumps(match_list)



@app.route('/predictions')
def predictions():
    return render_template('predictions.html')

@app.route('/model_presentation')
def model_presentation():
    return render_template('model_presentation.html')

@app.route('/home')
def home():
    return render_template('home.html')


if __name__ == '__main__':
    app.run(debug=True)